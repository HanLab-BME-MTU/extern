This set of XML Documents for Web Coverage Service (WCS) Version 1.0.0 
has been edited to reflect the corrigendum to document OGC 03-065r6 that 
is specified in document OGC 05-076 plus the corrigendum based on the 
change requests: 
OGC 05-068r1 "Store xlinks.xsd file at a fixed location"
OGC 05-081r2 "Change to use relative paths"

Arliss Whiteside, 2005-11-22

